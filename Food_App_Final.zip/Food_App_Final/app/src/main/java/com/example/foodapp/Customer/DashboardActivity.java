package com.example.foodapp.Customer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.foodapp.LoginActivity;
import com.example.foodapp.ProfileActivity;
import com.example.foodapp.R;
import com.example.foodapp.ResMenus.DebonairsMenuActivity;
import com.example.foodapp.ResMenus.KfcMenuActivity;
import com.example.foodapp.ResMenus.NandosMenuActivity;

public class DashboardActivity extends AppCompatActivity {

    private SharedPreferences preferences;
    private CardView debonaires, nandos, kfc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        preferences = getSharedPreferences("login", MODE_PRIVATE);

        //toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        //cardviews for restaurants
        debonaires = (CardView) findViewById(R.id.debonaires);
        nandos = (CardView) findViewById(R.id.Nandos);
        kfc = (CardView) findViewById(R.id.kfc);

        debonaires.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), DebonairsMenuActivity.class));
                finish();
            }
        });
        nandos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), NandosMenuActivity.class));
                finish();
            }
        });
        kfc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), KfcMenuActivity.class));
                finish();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.Profile:
                startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                finish();
                return  true;

            case R.id.cart:
                startActivity(new Intent(getApplicationContext(), CartActivity.class));
                finish();
                return  true;
            case R.id.logout:
                preferences.edit().putBoolean("logged", false).apply();
                    startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                    finish();
                Toast.makeText(this, "Logging out", Toast.LENGTH_SHORT).show();
                return  true;
        }

        return super.onOptionsItemSelected(item);
    }

}