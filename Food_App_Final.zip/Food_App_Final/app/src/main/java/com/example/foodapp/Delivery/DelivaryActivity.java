package com.example.foodapp.Delivery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.foodapp.LoginActivity;
import com.example.foodapp.ProfileActivity;
import com.example.foodapp.R;

public class DelivaryActivity extends AppCompatActivity {

    private SharedPreferences pref;
    private String UserAccount;
    Menu cart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivary);
        pref = getSharedPreferences("login", MODE_PRIVATE);

        //EditText user_name = findViewById(R.id.);

        //toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        cart = findViewById(R.id.cart);
        UserAccount = pref.getString("user","NULL");


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_delivery, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.Profile:
                startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                finish();
                return  true;

            case R.id.logout:
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                finish();
                Toast.makeText(this, "Logging out", Toast.LENGTH_SHORT).show();
                return  true;
        }

        return super.onOptionsItemSelected(item);
    }
}