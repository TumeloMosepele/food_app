package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.foodapp.Customer.DashboardActivity;
import com.example.foodapp.Delivery.DelivaryActivity;
import com.example.foodapp.ResMenus.AdminPanelDashboard;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private SharedPreferences preferences;
    private EditText loginEmail, loginPassword;
    private TextView signUp;
    private Button loginButton;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        preferences = getSharedPreferences("login", MODE_PRIVATE);

        loginEmail = findViewById(R.id.login_email);
        loginPassword = findViewById(R.id.login_password);
        signUp = findViewById(R.id.navigate_to_signup);
        loginButton = findViewById(R.id.login_button);
        progressBar = findViewById(R.id.progressBar);

        loginEmail.setText("admin@foodapp.com");
        loginPassword.setText("Test1234");

        autoLogin();

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String Email = loginEmail.getText().toString().trim();
                String Password = loginPassword.getText().toString().trim();

                if (validateInputs().equals(true)) {
                    Login(Email, Password);
                }
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSignUpActivity();
            }
        });

    }

    @Override
    public void onBackPressed() {
        finish();
        System.exit(0);
    }

    public void openSignUpActivity() {
        Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
        startActivity(intent);
        finish();
    }

    private void navigateToDashboard(String value) {
        if (value.equals("Admin")) {
            startActivity(new Intent(getApplicationContext(), AdminPanelDashboard.class));
            finish();
        } else if (value.equals("User")) {
            preferences.edit().putBoolean("logged", true).apply();
            startActivity(new Intent(getApplicationContext(), DashboardActivity.class));
            finish();
        } else if (value.equals("Delivery")) {
            startActivity(new Intent(getApplicationContext(), DelivaryActivity.class));
            finish();
        }
    }

    private Boolean validateInputs() {
        return validateEmail().equals(true) && validatePassword().equals(true);
    }

    private Boolean validateEmail() {
        String val = loginEmail.getEditableText().toString().trim();
        String emailPattern = "^(.+)@(.+)$";

        if (val.isEmpty()) {
            loginEmail.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(emailPattern)) {
            loginEmail.setError("Invalid email address");
            return false;
        } else {
            loginEmail.setError(null);
            return true;
        }
    }

    private Boolean validatePassword() {
        String val = loginPassword.getEditableText().toString().trim();
        if (val.isEmpty()) {
            loginPassword.setError("Field cannot be empty");
            return false;
        } else {
            loginPassword.setError(null);
            return true;
        }
    }

    public void showToast(final String Text) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(LoginActivity.this,
                        Text, Toast.LENGTH_LONG).show();
            }
        });
    }

    public void autoLogin() {
        if (preferences.getBoolean("logged", false)) {
            Intent i = new Intent(LoginActivity.this, DashboardActivity.class);
            startActivity(i);
            finish();
        }
    }

    private void Login(final String email, final String password) {
        String URL = "https://myloanapp.000webhostapp.com/FoodApp/foodapp_login.php";
        StringRequest stringRequest;

        loginButton.setVisibility(View.INVISIBLE);
        progressBar.setVisibility(View.VISIBLE);

        stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("volley_response", response);

                try {
                    JSONObject object = new JSONObject(response);

                    if (!response.equals("error")) {

                        String user = object.getString("user").trim();
                        String name = object.getString("name").trim();
                        String email = object.getString("email").trim();
                        String mobile = object.getString("mobile").trim();

                        preferences.edit().putString("user", user).apply();
                        preferences.edit().putString("name", name).apply();
                        preferences.edit().putString("mobile", mobile).apply();
                        preferences.edit().putString("email", email).apply();

                        loginButton.setVisibility(View.VISIBLE);

                        navigateToDashboard(user);

                    } else {
                        showToast("Invalid Credentials ");
                        loginButton.setVisibility(View.VISIBLE);
                    }

                } catch (JSONException ex) {
                    ex.printStackTrace();
                    loginButton.setVisibility(View.VISIBLE);
                    progressBar.setVisibility(View.INVISIBLE);
                    showToast("Invalid Login Credentials");
                }

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loginButton.setVisibility(View.VISIBLE);
                        progressBar.setVisibility(View.INVISIBLE);
                        showToast("Error: Check Internet Connection");
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("email", email);
                params.put("password", password);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

}