package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.foodapp.Customer.DashboardActivity;
import com.example.foodapp.Delivery.DelivaryActivity;
import com.example.foodapp.ResMenus.AdminPanelDashboard;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    private String User, Email, Password;
    private SharedPreferences pref;
    private Button changePassword;
    private EditText oldPassword, newPassword, confirmPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        pref = getSharedPreferences("login", MODE_PRIVATE);

        ImageView back = findViewById(R.id.btnBack);
        EditText user_name = findViewById(R.id.txtName);
        EditText user_email = findViewById(R.id.txtEmail);
        EditText user_mobile = findViewById(R.id.txtMobile);
        oldPassword = findViewById(R.id.txtOldPassword);
        newPassword = findViewById(R.id.txtNewPassword);
        confirmPassword = findViewById(R.id.txtConfirmNewPassword);
        changePassword = findViewById(R.id.btnChangePassword);

        changePassword = findViewById(R.id.btnChangePassword);

        user_name.setText(pref.getString("name", "NULL"));
        user_email.setText(pref.getString("email", "NULL"));
        user_mobile.setText(pref.getString("mobile", "NULL"));

        User = pref.getString("user", "NULL");
        Email = pref.getString("email", "NULL");

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (User.equals("User")) {
                    startActivity(new Intent(getApplicationContext(), DashboardActivity.class));
                    finish();
                } else if (User.equals("Delivery")) {
                    startActivity(new Intent(getApplicationContext(), DelivaryActivity.class));
                    finish();
                } else if (User.equals("Admin")){
                    startActivity(new Intent(getApplicationContext(), AdminPanelDashboard.class));
                    finish();
                }
            }
        });

        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String OldPassword = oldPassword.getText().toString().trim();
                String NewPassword = Password;
                String UserEmail = Email;

                if (validatePassword().equals(true)) {
                    ChangePassword(Email, OldPassword, NewPassword);
                }

            }
        });
    }

    private Boolean validatePassword() {
        String inputA = newPassword.getEditableText().toString().trim();
        String inputB = confirmPassword.getEditableText().toString().trim();
        String inputC = oldPassword.getEditableText().toString().trim();
        String passwordPattern = "^" +
                "(?=.*[A-Za-z])" +  //any letter
                "(?=.*[0-9])" +     //at least 1 digit
                "(?=\\S+$)" +       //no whitespace
                ".{6,}" +            //at least 6 characters
                "$";

        if (inputA.isEmpty() && inputB.isEmpty() && inputC.isEmpty()) {
            oldPassword.setError("Field cannot be empty");
            newPassword.setError("Field cannot be empty");
            confirmPassword.setError("Field cannot be empty");
            return false;
        }

        if (inputC.isEmpty()) {
            oldPassword.setError("Field cannot be empty");
            return false;
        }

        if (!inputC.matches(passwordPattern)) {
            String error_msg = "Password requirements: letters, digits, minimum 6 characters";
            oldPassword.setError(error_msg);
            return false;
        }

        if (!inputA.equals(inputB)) {
            newPassword.setError("password do not match");
            confirmPassword.setError("password do not match");
            return false;
        }
        if (inputA.equals(inputB)) {
            if (inputA.matches(passwordPattern) && inputB.matches(passwordPattern)) {
                Password = newPassword.getText().toString().trim();
                newPassword.setError(null);
                confirmPassword.setError(null);
                return true;
            } else {
                String error_msg = "Password requirements: letters, digits, minimum 6 characters";
                newPassword.setError(error_msg);
                confirmPassword.setError(error_msg);
                return false;
            }
        } else {
            return false;
        }
    }

    public void showToast(final String Text) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(ProfileActivity.this,
                        Text, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void ChangePassword(final String email, final String oldPassword, final String newPassword) {

        String URL = "https://myloanapp.000webhostapp.com/FoodApp/foodapp_password.php";
        StringRequest stringRequest;

        changePassword.setVisibility(View.INVISIBLE);

        stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("volley_response", response);

                try {
                    JSONObject object = new JSONObject(response);
                    String success = object.getString("success");

                    if (success.equals("1")) {
                        showToast("Password Changed Successfully");
                        startActivity(new Intent(getApplicationContext(), DashboardActivity.class));
                        finish();

                    } else if (success.equals("2")) {
                        showToast("old Password doe not match");
                    } else {
                        showToast("Change Password Request failed");
                    }
                    changePassword.setVisibility(View.VISIBLE);

                } catch (JSONException ex) {
                    ex.printStackTrace();
                    changePassword.setVisibility(View.VISIBLE);
                    showToast("Request failed");
                }

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        changePassword.setVisibility(View.VISIBLE);
                        showToast("Error: Check Internet Connection");
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("email", email);
                params.put("oldPassword", oldPassword);
                params.put("newPassword", newPassword);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}