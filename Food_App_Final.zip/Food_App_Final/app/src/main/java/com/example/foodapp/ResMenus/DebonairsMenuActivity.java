package com.example.foodapp.ResMenus;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.foodapp.Customer.DashboardActivity;
import com.example.foodapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class DebonairsMenuActivity extends AppCompatActivity {

    private ImageButton veggieMeaButton, somethingMeattieBtn;
    private TextView veggieMealTxt, originalVeggiePrice, somethingMeatie, somthingMeatiePrice;

    //firebase
    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_debonairs_menu);

        mAuth = FirebaseAuth.getInstance();

        veggieMeaButton = findViewById(R.id.add_og_veggie_to_cart);
        veggieMealTxt = findViewById(R.id.veggie_meal);
        originalVeggiePrice =  findViewById(R.id.original_veggie_price);

        somethingMeatie = findViewById(R.id.something_meatie);
        somthingMeatiePrice = findViewById(R.id.something_meatie_price);

        somethingMeattieBtn = findViewById(R.id.something_meatie_btn);

        //toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        //Back button
        ImageView back = findViewById(R.id.btnBack);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getApplicationContext(), DashboardActivity.class));
                finish();

            }
        });

        veggieMeaButton = (ImageButton) findViewById(R.id.add_og_veggie_to_cart);
        veggieMealTxt = (TextView) findViewById(R.id.veggie_meal);
        originalVeggiePrice = (TextView) findViewById(R.id.original_veggie_price);

        somethingMeatie = (TextView) findViewById(R.id.something_meatie);
        somthingMeatiePrice = (TextView) findViewById(R.id.something_meatie_price);

        somethingMeattieBtn = (ImageButton) findViewById(R.id.something_meatie_btn);
        somethingMeattieBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addToCartt();
            }
        });

        veggieMeaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addToCart();
            }
        });

    }

    public void addToCart(){
        String mealName = veggieMealTxt.getText().toString();
        String mealPrice = originalVeggiePrice.getText().toString();

        mDatabase = FirebaseDatabase.getInstance();
        DatabaseReference myRef = mDatabase.getReference("Users").child("my order");
        //myRef.setValue(mealName);
        //myRef.setValue(mealPrice);

        HashMap<String,Object> data = new HashMap<>();
        data.put("name", mealName);
        data.put("price", mealPrice);
        myRef.setValue(data);

        Toast.makeText(this, "Added to cart", Toast.LENGTH_SHORT).show();

    }
    public void addToCartt(){
        String mealName = somethingMeatie.getText().toString();
        String mealPrice = somthingMeatiePrice.getText().toString();

        //////
        mAuth.getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Users");

        /////

        /*mAuth.getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance();
        DatabaseReference myRef ;//= mDatabase.getReference("Users");
        myRef = mDatabase.getReference(mAuth.getUid()).child("Users").push();*/

        //myRef.setValue(mealName);
        //myRef.setValue(mealPrice);

        HashMap<String,Object> data = new HashMap<>();
        data.put("name", mealName);
        data.put("price", mealPrice);
        //myRef.setValue(data);
        ref.setValue(data);
        ref.child("Cart");

        Toast.makeText(this, "Added to cart", Toast.LENGTH_SHORT).show();

    }
}