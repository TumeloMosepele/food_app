package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.foodapp.Customer.DashboardActivity;

import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity {

    private EditText signupUsername, signupEmail, signupPassword, signUpConfirmPassword, signupMobile;
    private Button signupButton;
    private ImageButton backButton;
    private String Password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        signupUsername = findViewById(R.id.signup_username);
        signupEmail = findViewById(R.id.signup_email);
        signupMobile = findViewById(R.id.signup_usermobile);
        signupPassword = findViewById(R.id.signup_password);
        signUpConfirmPassword = findViewById(R.id.signup_confirm_password);
        signupButton = findViewById(R.id.signup_button);
        backButton = findViewById(R.id.back_button);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String Name = signupUsername.getText().toString().trim();
                String Email = signupEmail.getText().toString().trim();
                String Mobile = signupMobile.getText().toString().trim();
                String UserID = "2020-" + randomCode();

                if (validateInputs().equals(true)) {
                    Register(UserID, Name, Email, Mobile, Password);
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private Boolean validateInputs() {
        return validateEmail().equals(true)
                && validatePassword().equals(true)
                && validateName().equals(true)
                && validateMobile().equals(true);
    }

    private Boolean validateName() {
        String val = signupUsername.getEditableText().toString().trim();
        if (val.isEmpty()) {
            signupUsername.setError("Field cannot be empty");
            return false;
        } else {
            signupUsername.setError(null);
            return true;
        }
    }

    private Boolean validateEmail() {
        String val = signupEmail.getEditableText().toString().trim();
        String emailPattern = "^(.+)@(.+)$";

        if (val.isEmpty()) {
            signupEmail.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(emailPattern)) {
            signupEmail.setError("Invalid email address");
            return false;
        } else {
            signupEmail.setError(null);
            return true;
        }
    }

    private Boolean validateMobile() {
        String val = signupMobile.getEditableText().toString().trim();
        if (val.isEmpty()) {
            signupMobile.setError("Field cannot be empty");
            return false;
        } else {
            signupUsername.setError(null);
            return true;
        }
    }

    private Boolean validatePassword() {
        String val = signupPassword.getEditableText().toString().trim();
        String val1 = signUpConfirmPassword.getEditableText().toString().trim();
        String passwordPattern = "^" +
                "(?=.*[A-Za-z])" +  //any letter
                "(?=.*[0-9])" +     //at least 1 digit
                "(?=\\S+$)" +       //no whitespace
                ".{6,}" +            //at least 6 characters
                "$";

        if (val.isEmpty() && val1.isEmpty()) {
            signupPassword.setError("Field cannot be empty");
            signUpConfirmPassword.setError("Field cannot be empty");
            return false;
        }

        if (!val.equals(val1)) {
            signupPassword.setError("password do not match");
            signUpConfirmPassword.setError("password do not match");
            return false;
        }
        if (val.equals(val1)) {
            if (val.matches(passwordPattern) && val1.matches(passwordPattern)) {
                Password = signupPassword.getText().toString().trim();
                signupPassword.setError(null);
                signUpConfirmPassword.setError(null);
                return true;
            } else {
                String error_msg = "Password requirements: letters, digits, minimum 6 characters";
                signupPassword.setError(error_msg);
                signUpConfirmPassword.setError(error_msg);
                return false;
            }
        } else {
            return false;
        }
    }

    protected String randomCode() {
        int length = 5;
        return RandomStringUtils.random(length, false, true);
    }

    public void showToast(final String Text) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(SignUpActivity.this,
                        Text, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void Register(final String userID, final String name, final String email,
                          final String mobile, final String password) {

        String URL = "https://myloanapp.000webhostapp.com/FoodApp/foodapp_register.php";
        StringRequest stringRequest;

        signupButton.setVisibility(View.INVISIBLE);

        stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("volley_response", response);

                try {
                    JSONObject object = new JSONObject(response);
                    String success = object.getString("success");

                    if (success.equals("1")) {
                        showToast("Registration Successful ");
                        startActivity(new Intent(getApplicationContext(), DashboardActivity.class));
                        finish();

                    } else if (success.equals("2")) {
                        showToast("Email been used to create account already");
                    } else {
                        showToast("Registration failed ");
                    }
                    signupButton.setVisibility(View.VISIBLE);

                } catch (JSONException ex) {
                    ex.printStackTrace();
                    signupButton.setVisibility(View.VISIBLE);
                    showToast("Request failed");
                }

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        signupButton.setVisibility(View.VISIBLE);
                        showToast("Error: Check Internet Connection");
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("userID", userID);
                params.put("name", name);
                params.put("email", email);
                params.put("mobile", mobile);
                params.put("password", password);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

}